﻿using System;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Xsl;

namespace sample.parse
{
    class Program
    {
        static void Main(string[] args)
        {
            //NOTE: The erml namespace was not getting loaded thus giving System.Xml.XPath.XPathException, so had to do complex looping in order to retrieve the data.
            XmlDocument xml = new XmlDocument();
            xml.Load("./content/SampleXml.xml");
            PrintGrantors(xml);
            CheckOriginalRecordingDate(xml);
            UpdateOriginalBeneficiary(xml);
            Console.WriteLine("Press any key to exit");
            Console.ReadKey();
        }
        static void PrintGrantors(XmlDocument xml)
        {
            XmlNodeList multipleElementList = xml.GetElementsByTagName("erml:Multiple");
            foreach (XmlNode multiple in multipleElementList)
            {
                if (multiple.Attributes["tooltip"].Value == "Grantor")
                {
                    Console.WriteLine("GRANTORS");
                    foreach (XmlNode single in multiple.ChildNodes)
                    {
                        Console.WriteLine($"{single.ChildNodes[0].InnerText} {single.ChildNodes[1].InnerText} {single.ChildNodes[2].InnerText} {single.ChildNodes[3].InnerText} {single.ChildNodes[4].InnerText}");
                    }
                    break;
                }
            }
        }

        static void UpdateOriginalBeneficiary(XmlDocument xml)
        {
            XmlNodeList exNodesList = xml.GetElementsByTagName("erml:EX");
            foreach (XmlNode exNode in exNodesList)
            {
                if (exNode.Attributes["type"].Value == "Original Beneficiary")
                {
                    foreach (XmlNode childExNode in exNode)
                    {
                        if (childExNode.Attributes["tooltip"].Value == "Original Beneficiary Last Name/Company")
                        {
                            childExNode.Attributes["required"].Value = "true";
                            break;
                        }
                    }
                    break;
                }
            }
            Console.WriteLine("Original Beneficiary Last Name/Company is updated to be required. File UpdatedXml.xml saved ");

            xml.Save("UpdatedXml.xml");
        }
        static void CheckOriginalRecordingDate(XmlDocument xml)
        {
            XmlNodeList dateNodesList = xml.GetElementsByTagName("erml:Date");
            foreach (XmlNode dateNode in dateNodesList)
            {
                if (dateNode.Attributes["LabelKey"].Value == "OriginalRecordingDate")
                {
                    var originalRecordingDate = DateTime.Parse(dateNode.InnerText);
                    if (DateTime.Compare(originalRecordingDate, DateTime.Now) < 0)
                    {
                        Console.WriteLine("Warning: Recorded data  is not latest.");

                    }
                    break;
                }
            }
        }
    }
}
